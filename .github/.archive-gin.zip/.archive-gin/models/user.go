
package models

import (
	"time"
)

// User 定义
type User struct {
	UserID     int64  `db:"user_id"`
	Email      string `db:"email"`
	Password   string `db:"password"`
	CreateTime time.Time `db:"create_time`
	UpdateTime time.Time `db:"update_time"`
	Status     int16  `db:"status"`
}
